# 11-8-phase3
I've been working on this workout app for about a day and a half. I plan on making it track your workouts and weight. It is currently in the early stages of a prototype.

package com.example.navigation_slides.ui.menu;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.navigation_slides.R;
import com.example.navigation_slides.ui.menu.CalendarUtils;
import com.example.navigation_slides.ui.menu.Event;

import java.time.LocalTime;

public class EventEditActivity extends AppCompatActivity {

    private EditText workoutNameET, workoutRepsET;
    private TextView workoutDateTV;

    private LocalTime time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        initWidgets();
        time = LocalTime.now();
        workoutDateTV.setText("Date: " + CalendarUtils.formattedDate(CalendarUtils.selectedDate));
    }

    private void initWidgets() {
        workoutNameET = findViewById(R.id.workoutNameET);
        workoutRepsET = findViewById(R.id.workoutRepsET);
        workoutDateTV = findViewById(R.id.workoutDateTV);
    }

    public void saveWorkoutAction(View view) {

        String workoutName = workoutNameET.getText().toString();
        String workoutReps = workoutRepsET.getText().toString();
        Event newEvent = new Event (workoutName, CalendarUtils.selectedDate, workoutReps);
        Event.eventsList.add(newEvent);
        finish();
    }
}

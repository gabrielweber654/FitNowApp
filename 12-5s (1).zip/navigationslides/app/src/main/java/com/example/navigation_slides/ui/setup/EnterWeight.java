package com.example.navigation_slides.ui.setup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.navigation_slides.R;

public class EnterWeight extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight);
        Intent intent = getIntent();

        /*constraintLayout = (ConstraintLayout) findViewById(R.id.layout);
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(3000);
        animationDrawable.setExitFadeDuration(2000);
        animationDrawable.start();*/
    }

    public void displayBirthday(View view){
        Intent intent = new Intent(this, EnterBirthday.class);
        //EditText editText1 = (EditText) findViewById(R.id.editTextTextPersonName);
        //EditText editText2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        //String message1 = editText1.getText().toString();
        //String message2 = editText2.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE1, message1);
        //intent.putExtra(EXTRA_MESSAGE2, message2);
        startActivity(intent);
    }

}


package com.example.navigation_slides.ui.crossfit;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.navigation_slides.R;
import com.example.navigation_slides.databinding.FragmentCrossfitBinding;
import com.example.navigation_slides.ui.setup.AddPresetWorkout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class CrossfitFragment extends Fragment {

    private FragmentCrossfitBinding binding;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentCrossfitBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        FloatingActionButton btnOpen = (FloatingActionButton) root.findViewById(R.id.fab);

        btnOpen.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent in = new Intent(getActivity(), AddPresetWorkout.class);
                startActivity(in);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
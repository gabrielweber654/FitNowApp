package com.example.navigation_slides.ui.menu;

import static android.content.Intent.getIntent;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.navigation_slides.R;
import com.example.navigation_slides.databinding.FragmentMenuBinding;
import com.example.navigation_slides.ui.setup.AddWorkout;
import com.example.navigation_slides.ui.setup.EnterName;
import com.example.navigation_slides.ui.setup.EnterWeight;

public class MenuFragment extends Fragment implements View.OnClickListener{

    private FragmentMenuBinding binding;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentMenuBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Button b1 = (Button) root.findViewById(R.id.bttn_sun);
        Button b2 = (Button) root.findViewById(R.id.bttn_mon);
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                b2.setBackgroundDrawable(getResources().getDrawable(R.drawable.label_bg));
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                b1.setBackgroundDrawable(getResources().getDrawable(R.drawable.label_bg));
            }
        });

        Button btnOpen = (Button) root.findViewById(R.id.add_workout_btn);
        TextView day = (TextView) root.findViewById(R.id.text_day);
        TextView w1 = (TextView) root.findViewById(R.id.text_workout1);
        TextView w2 = (TextView) root.findViewById(R.id.text_workout2);
        TextView w3 = (TextView) root.findViewById(R.id.text_workout3);
        TextView w4 = (TextView) root.findViewById(R.id.text_workout4);
        TextView w5 = (TextView) root.findViewById(R.id.text_workout5);
        TextView w6 = (TextView) root.findViewById(R.id.text_workout6);
        TextView w7 = (TextView) root.findViewById(R.id.text_workout7);
        w1.setTextSize(25);
        w2.setTextSize(25);
        w3.setTextSize(25);
        w4.setTextSize(25);
        w5.setTextSize(25);
        w6.setTextSize(25);
        w7.setTextSize(25);
        btnOpen.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent in = new Intent(getActivity(), AddWorkout.class);
                startActivity(in);
            }
        });

        Button btnSunday = (Button) root.findViewById(R.id.bttn_sun);
        btnSunday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Sunday");
                w1.setText("Curls | 3x12");
                w2.setText("Bench Press | 3x12");
                w3.setText("Push-ups | 5x10");
                w4.setText("Jumping Jacks | 3x10");
                w5.setText("Chest Dips | 3x10");
                w6.setText("Burpees | 3 min");
                w7.setText("Chest Stretch | 5 min");
            }
        });

        Button btnMonday = (Button) root.findViewById(R.id.bttn_mon);
        btnMonday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Monday");
                w1.setText("Squats | 4x7");
                w2.setText("RDL | 5x10");
                w3.setText("Box Jumps | 2 min");
                w4.setText("Shoulder Press | 3x10");
                w5.setText("Side-Lat Raises | 3x10");
                w6.setText("Front-Lat Raises | 3x10");
                w7.setText("Rear-Delt Raises | 3x10");
            }
        });

        Button btnTuesday = (Button) root.findViewById(R.id.bttn_tues);
        btnTuesday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Tuesday");
                w1.setText("Jump Rope | 2 min");
                w2.setText("Rest | 30 sec");
                w3.setText("Jump Squat | 3x10");
                w4.setText("High Knees | 4x20");
                w5.setText("Climbers | 3 min");
                w6.setText("Rest | 30 sec");
                w7.setText("Plank | 1 min");
            }
        });

        Button btnWednesday = (Button) root.findViewById(R.id.bttn_wed);
        btnWednesday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Wednesday");
                w1.setText("Back Row | 4x5");
                w2.setText("Hammer Curls | 3x10");
                w3.setText("Tricep Press | 3x10");
                w4.setText("Barbell Curls | 3x10");
                w5.setText("Tricep Dips | 3x10");
                w6.setText("Skull-Crushers | 3x10");
                w7.setText("Pull-ups | 4x5");
            }
        });

        Button btnThursday = (Button) root.findViewById(R.id.bttn_thurs);
        btnThursday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Thursday");
                w1.setText("Arm Stretch | 1 min");
                w2.setText("Lunges | 3x10");
                w3.setText("Bench Press | 5x5");
                w4.setText("Goblet Squat | 3x10");
                w5.setText("Incline Press | 4x5");
                w6.setText("Calf Raises | 3x20");
                w7.setText("Run | 5 min");
            }
        });

        Button btnFriday = (Button) root.findViewById(R.id.bttn_fri);
        btnFriday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Friday");
                w1.setText("Box Jumps | 2 min");
                w2.setText("Jump Rope | 2 min");
                w3.setText("Pull-ups | 4x5");
                w4.setText("Rest | 30 sec");
                w5.setText("Climbers | 3 min");
                w6.setText("Run | 5 min");
                w7.setText("Walk | 5 min");
            }
        });

        Button btnSaturday = (Button) root.findViewById(R.id.bttn_sat);
        btnSaturday.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                day.setText("Saturday");
                w1.setText("Back Row | 4x5");
                w2.setText("Hammer Curls | 3x10");
                w3.setText("Tricep Press | 3x10");
                w4.setText("Goblet Squat | 3x10");
                w5.setText("Incline Press | 4x5");
                w6.setText("Calf Raises | 3x20");
                w7.setText("Pull-ups | 4x5");
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onClick(View view) {

    }
}
package com.example.navigation_slides.ui.setup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.navigation_slides.MainActivity;
import com.example.navigation_slides.R;

public class AddPresetWorkout extends AppCompatActivity {

    private EditText workoutNameET, workoutRepsET;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_workout);
        //Intent intent = getIntent();

        /*constraintLayout = (ConstraintLayout) findViewById(R.id.layout);
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(3000);
        animationDrawable.setExitFadeDuration(2000);
        animationDrawable.start();*/
    }

    public void displayMenu(View view){
        Intent intent = new Intent(this, MainActivity.class);
        //EditText editText1 = (EditText) findViewById(R.id.editTextTextPersonName);
        //EditText editText2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        //String message1 = editText1.getText().toString();
        //String message2 = editText2.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE1, message1);
        //intent.putExtra(EXTRA_MESSAGE2, message2);
        startActivity(intent);
    }

}


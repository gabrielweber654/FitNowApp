package com.example.navigation_slides.ui.setup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.navigation_slides.R;

public class EnterWorkoutExperience extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_workout_experience);
        Intent intent = getIntent();
        Spinner spinnerLanguages = findViewById(R.id.spinner_style);

        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource
                (this, R.array.experience, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        spinnerLanguages.setAdapter((adapter));

        /*constraintLayout = (ConstraintLayout) findViewById(R.id.layout);
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(3000);
        animationDrawable.setExitFadeDuration(2000);
        animationDrawable.start();*/
    }

    public void displayWorkoutStyle(View view){
        Intent intent = getIntent();
        String message1 = intent.getStringExtra("First_Name");
        String message2 = intent.getStringExtra("Last_Name");
        String message3 = intent.getStringExtra("Weight");
        String message4 = intent.getStringExtra("Birthday");


       // EditText editText5 = (EditText) findViewById(R.id.editTextTextPersonName);
        //String message5 = editText4.getText().toString();


        Intent intent2 = new Intent(this, EnterWorkoutStyle.class);
        intent2.putExtra("First_Name", message1);
        intent2.putExtra("Last_Name", message2);
        intent2.putExtra("Weight", message3);
        intent2.putExtra("Birthday", message4);
        startActivity(intent2);



        //EditText editText1 = (EditText) findViewById(R.id.editTextTextPersonName);
        //EditText editText2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        //String message1 = editText1.getText().toString();
        //String message2 = editText2.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE1, message1);
        //intent.putExtra(EXTRA_MESSAGE2, message2);
    }

}


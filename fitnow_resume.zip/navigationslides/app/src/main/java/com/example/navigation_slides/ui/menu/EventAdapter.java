package com.example.navigation_slides.ui.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.navigation_slides.R;
import com.example.navigation_slides.ui.menu.Event;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {


    public EventAdapter(@NonNull Context context, List<Event> events) {
        super(context, 0, events);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Event event = getItem(position);

        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.event_cell, parent, false);

        TextView workoutCellTV = convertView.findViewById(R.id.workoutCellTV);

        String workoutTitle = event.getName() + " " + event.getReps();
        workoutCellTV.setText(workoutTitle);
        return convertView;
    }
}


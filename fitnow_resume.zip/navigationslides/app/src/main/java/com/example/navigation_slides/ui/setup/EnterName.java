package com.example.navigation_slides.ui.setup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.navigation_slides.R;

public class EnterName extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_name);
        //Intent intent = getIntent();

        /*constraintLayout = (ConstraintLayout) findViewById(R.id.layout);
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(3000);
        animationDrawable.setExitFadeDuration(2000);
        animationDrawable.start();*/
    }

    public void displayWeight(View view){
        Intent intent = new Intent(this, EnterWeight.class);
        EditText editText1 = (EditText) findViewById(R.id.editTextTextPersonName);
        EditText editText2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        String message1 = editText1.getText().toString();
        String message2 = editText2.getText().toString();
        intent.putExtra("First_Name", message1);
        intent.putExtra("Last_Name", message2);
        startActivity(intent);
    }

}

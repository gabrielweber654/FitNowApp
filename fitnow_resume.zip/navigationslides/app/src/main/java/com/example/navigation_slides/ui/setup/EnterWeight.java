package com.example.navigation_slides.ui.setup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.navigation_slides.R;

public class EnterWeight extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight);
        Intent intent = getIntent();

        /*constraintLayout = (ConstraintLayout) findViewById(R.id.layout);
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(3000);
        animationDrawable.setExitFadeDuration(2000);
        animationDrawable.start();*/
    }

    public void displayBirthday(View view){
        Intent intent = getIntent();
        String message1 = intent.getStringExtra("First_Name");
        String message2 = intent.getStringExtra("Last_Name");

        //TextView mResultTv = findViewById(R.id.resultTv);
        //mResultTv.setText("Name: "+first_name+"\nEmail: "+last_name+);

        EditText editText3 = (EditText) findViewById(R.id.editTextTextPersonName);
        String message3 = editText3.getText().toString();

        Intent intent2 = new Intent(this, EnterBirthday.class);
        intent2.putExtra("First_Name", message1);
        intent2.putExtra("Last_Name", message2);
        intent2.putExtra("Weight", message3);
        startActivity(intent2);
    }

}


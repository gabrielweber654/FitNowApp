package com.example.navigation_slides.ui.bio;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class BioViewModel extends ViewModel {

    private static LiveData<String> mText;

    public BioViewModel() {
        mText = new MutableLiveData<>("Bio Page");
    }

    public static LiveData<String> getText() {
        return mText;
    }
}
package com.example.navigation_slides.ui.bodybuilding;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class BodybuildingViewModel extends ViewModel {

    private static LiveData<String> mText;

    public BodybuildingViewModel() {
        mText = new MutableLiveData<>("Bodybuilding Page");
    }

    public static LiveData<String> getText() {
        return mText;
    }
}
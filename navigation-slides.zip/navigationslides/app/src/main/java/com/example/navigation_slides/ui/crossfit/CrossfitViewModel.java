package com.example.navigation_slides.ui.crossfit;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class CrossfitViewModel extends ViewModel {

    private static LiveData<String> mText;

    public CrossfitViewModel() {
        mText = new MutableLiveData<>("Crossfit Page");
    }

    public static LiveData<String> getText() {
        return mText;
    }
}
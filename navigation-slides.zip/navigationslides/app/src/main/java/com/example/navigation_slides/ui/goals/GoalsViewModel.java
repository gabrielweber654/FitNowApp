package com.example.navigation_slides.ui.goals;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GoalsViewModel extends ViewModel {

    private static LiveData<String> mText;

    public GoalsViewModel() {
        mText = new MutableLiveData<>("Goals Page");
    }

    public static LiveData<String> getText() {
        return mText;
    }
}